import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Right here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Right extends Actor
{
    /**
     * Act - do whatever the Right wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(Greenfoot.isKeyDown("j")) {
            this.setImage("RightPress.png");
            //if(!Left.leftTurn) Left.resetTimer();
        }
        else this.setImage("Right.png");
    }    
}

This is the images folder
